﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System;
using System.Windows.Forms;
using Novels.Core.Data;
using Novels.Core;
using Microsoft.EntityFrameworkCore;
using System.Threading;

namespace Novels.App
{
    public partial class NovelDetailView : UserControl
    {
        public NovelDetailView()
        {
            InitializeComponent();
        }


        public int Id { get; set; }

        public string NovelName
        {
            get { return lblName.Text; }
            set { lblName.Text = $"Name: {value}"; }
        }

        public string NovelNumber
        {
            get { return lblNumber.Text; }
            set { lblNumber.Text = $"Number of Chapters: {value}"; }
        }

        public string Summary
        {
            get => lblSummary.Text;
            set => lblSummary.Text = value;
        }

        public string CoverPhotoUrl
        {
            get => picCoverPhoto.ImageLocation;
            set => picCoverPhoto.ImageLocation = value;
        }

        public void SetTags(string tags)
        {
            lblTags.Text = $"Tags: {tags}"; ;
        }


        public void SetNovel(NovelModel novel)
        {
            Id = novel.Id;
            lblName.Text = $"Name: {novel.Name}";
            lblNumber.Text = $"Number of Chapters: {novel.Chapter}";
            lblTags.Text = $"Tags: {novel.Tags.Replace(',','\n')}";
            lblSummary.Text = novel.Summary;
            ckIsRead.Checked = novel.IsRead ?? false;
        }

        private void btnExport_Click(object sender, EventArgs e)
        {
            using (var context = new NovelContext())
            {
                NovelManager catalogLoader = new NovelManager(context);

                //await catalogLoader.UpdateAll() ;
                catalogLoader.Export(context.Novels.FirstOrDefault(c => c.Id == Id)).GetAwaiter().GetResult();


            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            using (var context = new NovelContext())
            {
                NovelManager catalogLoader = new NovelManager(context);

                var novel = context.Novels.FirstOrDefault(c => c.Id == Id);
                //await catalogLoader.UpdateAll() ;
                catalogLoader.Update(novel).GetAwaiter().GetResult();

                context.Update(novel);
                context.SaveChanges();

            }
        }

        private void ckIsRead_CheckedChanged(object sender, EventArgs e)
        {
            using (var context = new NovelContext())
            {
                NovelManager catalogLoader = new NovelManager(context);

                //await catalogLoader.UpdateAll() ;
                var novel = context.Novels.FirstOrDefault(c => c.Id == Id);
                novel.IsRead = true;
                context.Update(novel);
                context.SaveChanges();

            }
        }
    }
}
