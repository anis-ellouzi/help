﻿using System.Windows.Forms;
using System;
using System.Linq;
using System.Windows.Forms;
using Novels.Core.Data;
using Novels.App;

using System;
using System.Linq;
using System.Windows.Forms;
using Microsoft.EntityFrameworkCore;

namespace Novels.App
{
    public partial class MainForm : Form
    {
        private NovelContext _context;
        public MainForm()
        {
            InitializeComponent();
            _context = new NovelContext();
            dataGridView1.DataSource = GetNovels();
            HideIdColumn();
        }

        private List<NovelModel> GetNovels()
        {
            var novels = _context.Novels.ToList()
                .Where(novel =>
                    !string.IsNullOrWhiteSpace(novel.Tags) &&
                    !string.IsNullOrWhiteSpace(novel.Chapter) &&
                    !novel.Tags.ToLowerInvariant().Contains("yuri") &&
                    !novel.Tags.ToLowerInvariant().Contains("yaoi") &&
                    !novel.Tags.ToLowerInvariant().Contains("shoujo") &&
                    !novel.Tags.ToLowerInvariant().Contains("femaleprotagonist") &&
                    !novel.Tags.ToLowerInvariant().Contains("urban") &&
                    !novel.Tags.ToLowerInvariant().Contains("fan-fiction") &&
                    !novel.Tags.ToLowerInvariant().Contains("gender-bender") &&
                    !novel.Tags.ToLowerInvariant().Contains("beautifulfemaleLead") &&
                    !novel.Tags.ToLowerInvariant().Contains("femaleprotagonist") &&
                    !novel.Tags.ToLowerInvariant().Contains("josei") &&
                    !novel.Tags.ToLowerInvariant().Contains("romance") &&
                    !novel.Tags.ToLowerInvariant().Contains("histori") &&
                    //!novel.Tags.Contains("Romance") &&
                    decimal.Parse(novel.Chapter) > 299 &&
                    ((novel.IsRead.HasValue && !novel.IsRead.Value) || !novel.IsRead.HasValue) &&
                     !string.IsNullOrWhiteSpace(novel.Summary) &&
                    (
                    (
                      (
                       novel.Summary.ToLowerInvariant().Contains("family") ||
                       novel.Summary.ToLowerInvariant().Contains("clan") ||
                       novel.Summary.ToLowerInvariant().Contains("children") ||
                       novel.Summary.ToLowerInvariant().Contains("blessing") ||
                       novel.Summary.ToLowerInvariant().Contains("concubine") ||
                       novel.Summary.ToLowerInvariant().Contains("marry")
                      ) &&
                      novel.Summary.ToLowerInvariant().Contains("system") &&
                      novel.Summary.ToLowerInvariant().Contains("many")
                    ) ||
                    (
                       novel.Name.ToLowerInvariant().Contains("family") ||
                       novel.Name.ToLowerInvariant().Contains("clan") ||
                       novel.Name.ToLowerInvariant().Contains("children") ||
                       novel.Name.ToLowerInvariant().Contains("blessing") ||
                       novel.Name.ToLowerInvariant().Contains("concubine") ||
                       novel.Name.ToLowerInvariant().Contains("marry")
                    )
                    ))
                .OrderByDescending(c => decimal.Parse(c.Chapter))
                    //!novel.UpdatedOn.HasValue)
                .ToList();
            return novels;
        }


        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                var selectedNovel = (NovelModel)dataGridView1.Rows[e.RowIndex].DataBoundItem;
                //novelDetailView1.Id = selectedNovel.Id;
                //novelDetailView1.NovelName = selectedNovel.Name;
                //novelDetailView1.NovelNumber = selectedNovel.Chapter.ToString();
                //novelDetailView1.Summary = selectedNovel.Summary;
                //novelDetailView1.SetTags(selectedNovel.Tags);
                //novelDetailView1.CoverPhotoUrl = selectedNovel.CoverUrl;

                novelDetailView1.SetNovel(selectedNovel);
            }
        }

        private void searchParametersControl1_SearchClicked(object sender, EventArgs e)
        {
            var nameSearch = searchParametersControl1.NameSearch;
            var tagSearch = searchParametersControl1.TagSearch;
            var minNumber = searchParametersControl1.MinNumber;
            var maxNumber = searchParametersControl1.MaxNumber;
            var query = GetNovels().AsQueryable();
            
            if (!string.IsNullOrEmpty(nameSearch))
            {
                query = query.Where(n => n.Name.ToLowerInvariant().Contains(nameSearch));
            }

            if (!string.IsNullOrEmpty(tagSearch))
            {
                var selectedTags = tagSearch.Split(',').Select(tag => tag.ToLowerInvariant().Trim());
                query = query.Where(n => !string.IsNullOrWhiteSpace(n.Tags) && selectedTags.Any(tag => n.Tags.ToLowerInvariant().Contains(tag)));
            }

            if (minNumber > 0)
            {
                query = query.Where(n => !string.IsNullOrWhiteSpace(n.Chapter) && decimal.Parse(n.Chapter) >= minNumber);
            }

            if (maxNumber > 0)
            {
                query = query.Where(n => !string.IsNullOrWhiteSpace(n.Chapter) &&  decimal.Parse(n.Chapter) <= maxNumber);
            }

            //dataGridView1.DataSource = query.ToList();
            // Implement search logic using these parameters
            // Example:
            // var filteredNovels = dbContext.Novels.Where(n => n.Name.Contains(nameSearch) && 
            //      n.Tags.Contains(tagSearch) && 
            //      n.Number >= (minNumber ?? 0) && 
            //      n.Number <= (maxNumber ?? int.MaxValue)).ToList();
            // dataGridView1.DataSource = filteredNovels;

            dataGridView1.DataSource = query.ToList();
        }

    }
}
