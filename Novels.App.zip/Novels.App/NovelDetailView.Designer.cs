﻿
namespace Novels.App
{
    partial class NovelDetailView
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            splitContainer1 = new SplitContainer();
            btnExport = new Button();
            lblTags = new Label();
            picCoverPhoto = new PictureBox();
            btnUpdate = new Button();
            lblNumber = new Label();
            lblName = new Label();
            lblSummary = new TextBox();
            ckIsRead = new CheckBox();
            ((System.ComponentModel.ISupportInitialize)splitContainer1).BeginInit();
            splitContainer1.Panel1.SuspendLayout();
            splitContainer1.Panel2.SuspendLayout();
            splitContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)picCoverPhoto).BeginInit();
            SuspendLayout();
            // 
            // splitContainer1
            // 
            splitContainer1.Dock = DockStyle.Fill;
            splitContainer1.Location = new Point(0, 0);
            splitContainer1.Name = "splitContainer1";
            splitContainer1.Orientation = Orientation.Horizontal;
            // 
            // splitContainer1.Panel1
            // 
            splitContainer1.Panel1.Controls.Add(ckIsRead);
            splitContainer1.Panel1.Controls.Add(btnExport);
            splitContainer1.Panel1.Controls.Add(lblTags);
            splitContainer1.Panel1.Controls.Add(picCoverPhoto);
            splitContainer1.Panel1.Controls.Add(btnUpdate);
            splitContainer1.Panel1.Controls.Add(lblNumber);
            splitContainer1.Panel1.Controls.Add(lblName);
            // 
            // splitContainer1.Panel2
            // 
            splitContainer1.Panel2.Controls.Add(lblSummary);
            splitContainer1.Size = new Size(1061, 715);
            splitContainer1.SplitterDistance = 292;
            splitContainer1.TabIndex = 9;
            // 
            // btnExport
            // 
            btnExport.AutoSize = true;
            btnExport.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            btnExport.Location = new Point(634, 246);
            btnExport.Margin = new Padding(4, 5, 4, 5);
            btnExport.Name = "btnExport";
            btnExport.Size = new Size(31, 35);
            btnExport.TabIndex = 14;
            btnExport.Text = "↓";
            btnExport.UseVisualStyleBackColor = true;
            btnExport.Click += btnExport_Click;
            // 
            // lblTags
            // 
            lblTags.AutoSize = true;
            lblTags.Location = new Point(226, 67);
            lblTags.Margin = new Padding(4, 0, 4, 0);
            lblTags.Name = "lblTags";
            lblTags.Size = new Size(51, 25);
            lblTags.TabIndex = 12;
            lblTags.Text = "Tags:";
            // 
            // picCoverPhoto
            // 
            picCoverPhoto.Location = new Point(4, 33);
            picCoverPhoto.Margin = new Padding(4, 5, 4, 5);
            picCoverPhoto.Name = "picCoverPhoto";
            picCoverPhoto.Size = new Size(214, 248);
            picCoverPhoto.TabIndex = 11;
            picCoverPhoto.TabStop = false;
            // 
            // btnUpdate
            // 
            btnUpdate.AutoSize = true;
            btnUpdate.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            btnUpdate.Location = new Point(592, 246);
            btnUpdate.Margin = new Padding(4, 5, 4, 5);
            btnUpdate.Name = "btnUpdate";
            btnUpdate.Size = new Size(34, 35);
            btnUpdate.TabIndex = 13;
            btnUpdate.Text = "U";
            btnUpdate.UseVisualStyleBackColor = true;
            btnUpdate.Click += btnUpdate_Click;
            // 
            // lblNumber
            // 
            lblNumber.AutoSize = true;
            lblNumber.Location = new Point(226, 33);
            lblNumber.Margin = new Padding(4, 0, 4, 0);
            lblNumber.Name = "lblNumber";
            lblNumber.Size = new Size(81, 25);
            lblNumber.TabIndex = 10;
            lblNumber.Text = "Number:";
            // 
            // lblName
            // 
            lblName.AutoSize = true;
            lblName.Location = new Point(4, 3);
            lblName.Margin = new Padding(4, 0, 4, 0);
            lblName.Name = "lblName";
            lblName.Size = new Size(63, 25);
            lblName.TabIndex = 9;
            lblName.Text = "Name:";
            // 
            // lblSummary
            // 
            lblSummary.Location = new Point(4, 0);
            lblSummary.Margin = new Padding(4, 0, 4, 0);
            lblSummary.Multiline = true;
            lblSummary.Name = "lblSummary";
            lblSummary.Size = new Size(672, 400);
            lblSummary.TabIndex = 3;
            lblSummary.Text = "Summary:";
            // 
            // ckIsRead
            // 
            ckIsRead.AutoSize = true;
            ckIsRead.Location = new Point(495, 250);
            ckIsRead.Name = "ckIsRead";
            ckIsRead.Size = new Size(90, 29);
            ckIsRead.TabIndex = 15;
            ckIsRead.Text = "IsRead";
            ckIsRead.UseVisualStyleBackColor = true;
            ckIsRead.CheckedChanged += ckIsRead_CheckedChanged;
            // 
            // NovelDetailView
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            Controls.Add(splitContainer1);
            Margin = new Padding(4, 5, 4, 5);
            Name = "NovelDetailView";
            Size = new Size(1061, 715);
            splitContainer1.Panel1.ResumeLayout(false);
            splitContainer1.Panel1.PerformLayout();
            splitContainer1.Panel2.ResumeLayout(false);
            splitContainer1.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)splitContainer1).EndInit();
            splitContainer1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)picCoverPhoto).EndInit();
            ResumeLayout(false);
        }

        private SplitContainer splitContainer1;
        private Label lblTags;
        private PictureBox picCoverPhoto;
        private Label lblNumber;
        private Label lblName;
        private TextBox lblSummary;
        private Button btnExport;
        private Button btnUpdate;
        private CheckBox ckIsRead;
    }
}

