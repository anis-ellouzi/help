﻿
using Novels.App;

namespace Novels.App
{
    partial class MainForm
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            splitContainer1 = new SplitContainer();
            dataGridView1 = new DataGridView();
            novelDetailView1 = new NovelDetailView();
            searchParametersControl1 = new NovelSearchlView();
            ((System.ComponentModel.ISupportInitialize)splitContainer1).BeginInit();
            splitContainer1.Panel1.SuspendLayout();
            splitContainer1.Panel2.SuspendLayout();
            splitContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // splitContainer1
            // 
            splitContainer1.Dock = DockStyle.Fill;
            splitContainer1.Location = new Point(0, 70);
            splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            splitContainer1.Panel1.Controls.Add(dataGridView1);
            // 
            // splitContainer1.Panel2
            // 
            splitContainer1.Panel2.Controls.Add(novelDetailView1);
            splitContainer1.Size = new Size(920, 470);
            splitContainer1.SplitterDistance = 300;
            splitContainer1.TabIndex = 0;
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Dock = DockStyle.Fill;
            dataGridView1.Location = new Point(0, 0);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowHeadersWidth = 62;
            dataGridView1.Size = new Size(300, 470);
            dataGridView1.TabIndex = 0;
            dataGridView1.CellClick += dataGridView1_CellClick;
            // 
            // novelDetailView1
            // 
            novelDetailView1.CoverPhotoUrl = null;
            novelDetailView1.Dock = DockStyle.Fill;
            novelDetailView1.Id = 0;
            novelDetailView1.Location = new Point(0, 0);
            novelDetailView1.Margin = new Padding(4, 5, 4, 5);
            novelDetailView1.Name = "novelDetailView1";
            novelDetailView1.NovelName = "Name:";
            novelDetailView1.NovelNumber = "Number:";
            novelDetailView1.Size = new Size(616, 470);
            novelDetailView1.Summary = "Summary:";
            novelDetailView1.TabIndex = 1;
            // 
            // searchParametersControl1
            // 
            searchParametersControl1.Dock = DockStyle.Top;
            searchParametersControl1.Location = new Point(0, 0);
            searchParametersControl1.Margin = new Padding(4, 5, 4, 5);
            searchParametersControl1.Name = "searchParametersControl1";
            searchParametersControl1.Size = new Size(920, 70);
            searchParametersControl1.TabIndex = 1;
            searchParametersControl1.SearchClicked += searchParametersControl1_SearchClicked;
            // 
            // MainForm
            // 
            ClientSize = new Size(920, 540);
            Controls.Add(splitContainer1);
            Controls.Add(searchParametersControl1);
            Name = "MainForm";
            Text = "Novel Viewer";
            splitContainer1.Panel1.ResumeLayout(false);
            splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)splitContainer1).EndInit();
            splitContainer1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
        }

        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private NovelDetailView novelDetailView1;
        private NovelSearchlView searchParametersControl1;

        private void HideIdColumn()
        {
            List<string> list = new List<string>()
            {
                "Id",
                "Url",
                "Chapters",
                "Tags",
                "UpdatedOn",
                "Cover",
                "IsRead",
                "Summary",
                "Status"
            };

            foreach (var item in list)
            {
                if (dataGridView1.Columns.Contains(item))
                {
                    dataGridView1.Columns[item].Visible = false;
                }
            }
            // Assuming your DataGridView has a column named "Id"
            
            if (dataGridView1.Columns.Contains("Name"))
            {
                dataGridView1.Columns["Name"].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            }
        }
    }
}

