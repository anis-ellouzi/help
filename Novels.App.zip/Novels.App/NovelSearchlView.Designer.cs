﻿namespace Novels.App
{
    partial class NovelSearchlView
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            txtNameSearch = new TextBox();
            txtTagSearch = new TextBox();
            txtMinNumber = new TextBox();
            txtMaxNumber = new TextBox();
            btnSearch = new Button();
            lblSearchName = new Label();
            lblSearchTags = new Label();
            lblSearchMin = new Label();
            lblSearchMax = new Label();
            SuspendLayout();
            // 
            // txtNameSearch
            // 
            txtNameSearch.Location = new Point(67, 16);
            txtNameSearch.Margin = new Padding(4, 5, 4, 5);
            txtNameSearch.Name = "txtNameSearch";
            txtNameSearch.Size = new Size(150, 31);
            txtNameSearch.TabIndex = 0;
            // 
            // txtTagSearch
            // 
            txtTagSearch.Location = new Point(269, 16);
            txtTagSearch.Margin = new Padding(4, 5, 4, 5);
            txtTagSearch.Name = "txtTagSearch";
            txtTagSearch.Size = new Size(161, 31);
            txtTagSearch.TabIndex = 1;
            // 
            // txtMinNumber
            // 
            txtMinNumber.Location = new Point(510, 16);
            txtMinNumber.Margin = new Padding(4, 5, 4, 5);
            txtMinNumber.Name = "txtMinNumber";
            txtMinNumber.Size = new Size(70, 31);
            txtMinNumber.TabIndex = 2;
            // 
            // txtMaxNumber
            // 
            txtMaxNumber.Location = new Point(606, 16);
            txtMaxNumber.Margin = new Padding(4, 5, 4, 5);
            txtMaxNumber.Name = "txtMaxNumber";
            txtMaxNumber.Size = new Size(76, 31);
            txtMaxNumber.TabIndex = 3;
            // 
            // btnSearch
            // 
            btnSearch.Location = new Point(746, 16);
            btnSearch.Margin = new Padding(4, 5, 4, 5);
            btnSearch.Name = "btnSearch";
            btnSearch.Size = new Size(125, 39);
            btnSearch.TabIndex = 4;
            btnSearch.Text = "Search";
            btnSearch.UseVisualStyleBackColor = true;
            btnSearch.Click += btnSearch_Click;
            // 
            // lblSearchName
            // 
            lblSearchName.AutoSize = true;
            lblSearchName.Location = new Point(12, 16);
            lblSearchName.Margin = new Padding(4, 0, 4, 0);
            lblSearchName.Name = "lblSearchName";
            lblSearchName.Size = new Size(59, 25);
            lblSearchName.TabIndex = 5;
            lblSearchName.Text = "Name";
            // 
            // lblSearchTags
            // 
            lblSearchTags.AutoSize = true;
            lblSearchTags.Location = new Point(225, 16);
            lblSearchTags.Margin = new Padding(4, 0, 4, 0);
            lblSearchTags.Name = "lblSearchTags";
            lblSearchTags.Size = new Size(47, 25);
            lblSearchTags.TabIndex = 6;
            lblSearchTags.Text = "Tags";
            // 
            // lblSearchMin
            // 
            lblSearchMin.AutoSize = true;
            lblSearchMin.Location = new Point(438, 16);
            lblSearchMin.Margin = new Padding(4, 0, 4, 0);
            lblSearchMin.Name = "lblSearchMin";
            lblSearchMin.Size = new Size(77, 25);
            lblSearchMin.TabIndex = 7;
            lblSearchMin.Text = "Number";
            // 
            // lblSearchMax
            // 
            lblSearchMax.AutoSize = true;
            lblSearchMax.Location = new Point(588, 16);
            lblSearchMax.Margin = new Padding(4, 0, 4, 0);
            lblSearchMax.Name = "lblSearchMax";
            lblSearchMax.Size = new Size(19, 25);
            lblSearchMax.TabIndex = 8;
            lblSearchMax.Text = "-";
            // 
            // NovelSearchlView
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            Controls.Add(lblSearchMax);
            Controls.Add(lblSearchMin);
            Controls.Add(lblSearchTags);
            Controls.Add(lblSearchName);
            Controls.Add(btnSearch);
            Controls.Add(txtMaxNumber);
            Controls.Add(txtMinNumber);
            Controls.Add(txtTagSearch);
            Controls.Add(txtNameSearch);
            Margin = new Padding(4, 5, 4, 5);
            Name = "NovelSearchlView";
            Size = new Size(875, 71);
            ResumeLayout(false);
            PerformLayout();
        }

        private System.Windows.Forms.TextBox txtNameSearch;
        private System.Windows.Forms.TextBox txtTagSearch;
        private System.Windows.Forms.TextBox txtMinNumber;
        private System.Windows.Forms.TextBox txtMaxNumber;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.Label lblSearchName;
        private System.Windows.Forms.Label lblSearchTags;
        private System.Windows.Forms.Label lblSearchMin;
        private System.Windows.Forms.Label lblSearchMax;
    }
}

