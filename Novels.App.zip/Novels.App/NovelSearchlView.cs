﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


using System;
using System.Windows.Forms;

namespace Novels.App
{
    public partial class NovelSearchlView : UserControl
    {
        public event EventHandler SearchClicked;

        public NovelSearchlView()
        {
            InitializeComponent();
        }

        public string NameSearch => txtNameSearch.Text;

        public string TagSearch => txtTagSearch.Text;

        public int? MinNumber => int.TryParse(txtMinNumber.Text, out var value) ? value : (int?)null;

        public int? MaxNumber => int.TryParse(txtMaxNumber.Text, out var value) ? value : (int?)null;

        private void btnSearch_Click(object sender, EventArgs e)
        {
            SearchClicked?.Invoke(this, EventArgs.Empty);
        }
    }
}
