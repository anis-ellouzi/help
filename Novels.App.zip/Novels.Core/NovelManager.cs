﻿using System;
using System.Collections;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

using HtmlAgilityPack;
using QuickEPUB;
using Novels.Core.Data;
using System.Runtime.CompilerServices;
using Novels.Core.Downloader;

namespace Novels.Core
{
    public class NovelManager
    {
        private String _baseUrl = "https://www.wuxiaspot.com";
        private String _baseUrlAll = "https://www.wuxiaspot.com/list/all/all-onclick-{0}.html";
        private String _baseUrlTag = "https://www.wuxiaspot.com/e/tags/index.php?page={0}&tagid={1}&line=100&tempid=9";
        private String _baseUrlCategorie = "https://www.wuxiaspot.com/list/{0}/all-newstime-{1}.html";
        private HtmlDocument catalogDocument;
        private NovelContext _context;
        private IDownloader _downloader;
        private HtmlWeb _htmlWeb;
        public NovelManager(NovelContext context = null)
        {
            _context = context ?? new NovelContext();
            _downloader = new WuxiaDownloader();
            _htmlWeb = new HtmlWeb();
            _htmlWeb.PostResponse = (request, response) =>
            {
                if (response != null)
                {
                    var lastStatusCode = response.StatusCode;
                    if (lastStatusCode == (HttpStatusCode)429 && response.Headers["Retry-After"] != null)
                    {
                        int retryAfterSeconds;
                        if (int.TryParse(response.Headers["Retry-After"], out retryAfterSeconds))
                        {
                            Thread.Sleep(TimeSpan.FromSeconds(retryAfterSeconds));
                        }
                    }
                }
            };
        }

        #region GetAll

        public void GetAll()
        {
            List<NovelModel> allNovels = _context.Novels.ToList();
            List<NovelModel> allDownloadedNovels = _downloader.GetAll();


            List<NovelModel> allUpdateNovels = new List<NovelModel>();
            List<NovelModel> allAddNovels = new List<NovelModel>();

            // Add the results to the collection
            foreach (var s in allDownloadedNovels)
            {
                var serie = allNovels.FirstOrDefault(x => x.Name.ToLowerInvariant() == s.Name.ToLowerInvariant());
                if (serie != null)
                {
                    allUpdateNovels.Add(s);
                }
                else
                {
                    allAddNovels.Add(s);
                }
            }

            _context.Novels.UpdateRange(allUpdateNovels);
            _context.Novels.AddRange(allAddNovels);
            _context.SaveChanges();
        }

        #endregion GetAll

        #region UpdateAll

        public async Task UpdateAll()
        {
            List<NovelModel> seriesToLoad = _context.Novels.ToList()
                    .Where(novel =>
                        !string.IsNullOrWhiteSpace(novel.Tags) &&
                        !string.IsNullOrWhiteSpace(novel.Chapter) &&
                        //!novel.Chapter.Contains(".") &&
                        //!novel.Chapter.Contains("」") &&
                        //!novel.Chapter.Contains("]") &&
                        !novel.Tags.Contains("yuri") &&
                        !novel.Tags.Contains("Yaoi") &&
                        !novel.Tags.Contains("Shoujo") &&
                        !novel.Tags.Contains("FemaleProtagonist") &&
                        //!novel.Tags.Contains("urban") &&
                        //!novel.Tags.Contains("Fan-fiction") &&
                        !novel.Tags.Contains("Gender-bender") &&
                        !novel.Tags.Contains("BeautifulFemaleLead") &&
                        !novel.Tags.Contains("FemaleProtagonist") &&
                        !novel.Tags.Contains("Josei") &&
                        //!novel.Tags.Contains("Romance") &&
                        decimal.Parse(novel.Chapter) > 299) // && !novel.UpdatedOn.HasValue
                    .ToList(); ;
            ConcurrentBag<NovelModel> allSeries = new ConcurrentBag<NovelModel>();
            // Group seriesToLoad into batches of 5
            var batches = seriesToLoad.Select((novel, index) => new { novel, index })
                                      .GroupBy(x => x.index / 18)
                                      .Select(g => g.Select(x => x.novel).ToList())
                                      .ToList();
            int i = 0;

            // Process each batch in parallel
            foreach (var batch in batches)
            {
                var tasks = batch.Select(c => Update(c));
                await Task.WhenAll(tasks);
                //Thread.Sleep(10000);
                i++;
            }
            _context.Novels.UpdateRange(seriesToLoad);
            //_context.Novels.AddRange(allSeries.ToList());
            _context.SaveChanges();
        }

        public async Task Update(NovelModel novel)
        {
            try
            {
                ConcurrentBag<ChapterModel> allSeries = new ConcurrentBag<ChapterModel>();

                String novelName = novel.Name;
                String novelUrl = _baseUrl + novel.Url;
                var novelPage = _htmlWeb.Load(string.Format(novelUrl));
                var summaryNode = novelPage.DocumentNode.SelectSingleNode("//div[@class='summary']");
                var cat = novelPage.DocumentNode
                    .SelectSingleNode("//div[@class='categories']");
                //var tagsNode = novelPage.DocumentNode.SelectSingleNode("//div[@class='categories']");
                var coverNode = novelPage.DocumentNode.SelectSingleNode("//header[@class='novel-header']");
                //var imgNode = coverNode.SelectSingleNode(".//img");
                //string coverImageUrl = _baseUrl + imgNode.Attributes["src"].Value;
                novel.Summary = summaryNode.InnerHtml;

                var innerHtmlDoc = new HtmlDocument();
                innerHtmlDoc.LoadHtml(cat.InnerHtml);

                HtmlNodeCollection tagsNode = innerHtmlDoc.DocumentNode
                    .SelectNodes($"//li/a");
                foreach (HtmlNode item in tagsNode)
                {
                    //var innerHtmlDoc = new HtmlDocument();
                    //innerHtmlDoc.LoadHtml(item.InnerText);
                    novel.Tags = AddOrUpdate(novel.Tags, item.InnerText);
                }
                novel.UpdatedOn = DateTime.Now;
                Console.WriteLine($"Updated {novel.Name}");
            }
            catch (Exception)
            {
                Console.WriteLine($"Updated failed {novel.Name}");
            }

        }


        #endregion UpdateAll

        #region Export

        public async Task Export(NovelModel novel)
        {
            ConcurrentBag<ChapterModel> allSeries = new ConcurrentBag<ChapterModel>();
            // Create an Epub instance
            var doc = new Epub("Book Title", "Author Name");
            String storyName = novel.Name;
            String tocHeader = "<!DOCTYPE html><html><head><meta charset=\"utf-8\"></head><body><h1>" + storyName + "</h1><ul>";

            int chapters = int.Parse(novel.Chapter);
            String novelUrl = _baseUrl + novel.Url;
            String chapterUrl = novelUrl.Replace(".html", "_{0}.html");

            var novelPage = _htmlWeb.Load(string.Format(novelUrl));

            var summaryNode = novelPage.DocumentNode.SelectSingleNode("//div[@class='summary']");
            var coverNode = novelPage.DocumentNode.SelectSingleNode("//figure[@class='cover']");
            var imgNode = coverNode.SelectSingleNode(".//img");

            string coverImageUrl = _baseUrl + imgNode.Attributes["data-src"].Value;

            var imageData = GetImageStreamFromUrlAsync(coverImageUrl);
                // Convert the byte array to a MemoryStream
            MemoryStream coverStream = new MemoryStream(imageData);
            // Add the cover image to the EPUB resources
            doc.AddResource("cover.jpg", EpubResourceType.JPEG, coverStream);

            // Adding the cover page (with the fetched image)
            doc.AddSection("Cover", "<img src=\"cover.jpg\" alt=\"Cover\"/>");

            // Adding the summary section
            doc.AddSection("Summary", summaryNode.InnerHtml);

            // Create the list of numbers from start to end
            List<int> numbers = CreateNumberList(1, chapters);
            for (int chapNum = 1; chapNum < 5; chapNum++)
            {
                var chapterPage = _htmlWeb.Load(string.Format(chapterUrl, chapNum));
                int maxRetry = 3;
                bool isSucces = false;
                do
                {
                    isSucces = false;
                    try
                    {
                        Console.WriteLine("Fetching: " + storyName + "Chapter" + chapNum);
                        string next = "<a href=Chapter-\" + (chapNum - 1).ToString().PadLeft(5, '0') + \".html>Prev</a><a href=Chapter-" + (chapNum + 1).ToString().PadLeft(5, '0') + ".html>Next</a>";

                        var chapterNode = chapterPage.DocumentNode.SelectSingleNode("//div[@class='chapter-content']");
                        var titlesNode = chapterPage.DocumentNode.SelectSingleNode("//*[@class='titles']");
                        var trueChapNum = chapNum.ToString().PadLeft(5, '0');

                        var linkNodes = titlesNode?.SelectNodes(".//a");

                        // Remove each <a> tag found
                        if (linkNodes != null)
                        {
                            foreach (var linkNode in linkNodes)
                            {
                                linkNode.Remove();
                            }
                        }

                        // Get the modified HTML content
                        string title = titlesNode.InnerHtml;

                        string chapterContent = "<!DOCTYPE html><html><head><meta charset=\"utf-8\"></head>\n<body>" + titlesNode?.InnerHtml + "<Br/>" + chapterNode?.InnerHtml + " </body></html>";
                        allSeries.Add(new ChapterModel()
                        {
                            Number = chapNum,
                            Name = titlesNode.InnerText ?? "Chapter " + chapNum,
                            Content = chapterContent,
                            Url = string.Format(chapterUrl, chapNum)
                        });
                        isSucces = true;
                    }
                    catch (Exception e)
                    {
                        Console.WriteLine("Error in chapter " + chapNum);
                        //Console.WriteLine(e);

                    }
                    maxRetry++;
                } 
                while (maxRetry < 3 && !isSucces);
                
            }
            // Group numbers by packSize
            List<List<int>> groupedNumbers = GroupByPack(numbers, 5);
            foreach (var number in groupedNumbers)
            {
                int min = number.Min();
                int max = number.Max();
                Parallel.For(min, max, chapNum =>
                {
                    //ChapterLoader chapterLoader = new ChapterLoader(string.Format(chapterUrl, i));
                    //string body = chapterLoader.GetChapterBody();


                });

            }

            //// Add the CSS file referenced in the HTML content
            //using (var cssStream = new FileStream("custom.css", FileMode.Open))
            //{
            //    doc.AddResource("custom.css", EpubResourceType.CSS, cssStream);
            //}
            foreach (var item in allSeries.OrderBy(c => c.Number))
            {
                doc.AddSection(item.Name, item.Content);
            }
            // Export the result
            using (var fs = new FileStream(novel.Name + ".epub", FileMode.Create))
            {
                doc.Export(fs);
            }
        }

        #endregion

        public string AddOrUpdate(string tags, string tag)
        {
            if (!string.IsNullOrEmpty(tags) && tags.Contains(tag))
            {

            }
            else
            {
                tags = !string.IsNullOrEmpty(tags) ? string.Join(",", tags, tag) : tag;
            }

            return tags;
        }

        static byte[]? GetImageStreamFromUrlAsync(string imageUrl)
        {
            try
            {
                // Create an instance of WebClient
                using WebClient webClient = new WebClient();

                // Download the image data as a byte array
                byte[] imageData = webClient.DownloadData(imageUrl);

                return imageData;
            }
            catch (Exception)
            {

                throw;
            }
        }
        static List<int> CreateNumberList(int start, int end)
        {
            List<int> numbers = new List<int>();
            for (int i = start; i <= end; i++)
            {
                numbers.Add(i);
            }
            return numbers;
        }

        static List<List<int>> GroupByPack(List<int> numbers, int packSize)
        {
            List<List<int>> groupedNumbers = new List<List<int>>();

            for (int i = 0; i < numbers.Count; i += packSize)
            {
                List<int> group = numbers.GetRange(i, Math.Min(packSize, numbers.Count - i));
                groupedNumbers.Add(group);
            }

            return groupedNumbers;
        }

        static async Task<string> GetResponseTextAsync(string url)
        {
            using (HttpClient client = new HttpClient())
            {
                // Send the request and get the response
                using (HttpResponseMessage response = await client.GetAsync(url))
                {
                    response.EnsureSuccessStatusCode(); // Throws an exception if the HTTP response status is an error code

                    // Get the response content as a string
                    string responseText = await response.Content.ReadAsStringAsync();
                    return responseText;
                }
            }
        }


    }
}
