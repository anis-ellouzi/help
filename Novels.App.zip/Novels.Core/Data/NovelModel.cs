﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Novels.Core.Data
{
    public class NovelModel
    {
        [Key]
        public int Id { get; set; }  // Primary Key
        
        public string Url { get; set; }
        public string Name { get; set; }
        public string Chapter { get; set; }
        public string Status { get; set; }
        public string? Tags { get; set; }
        public string? Summary { get; set; }
        public DateTime? UpdatedOn { get; set; }
        public byte[]? Cover { get; set; }
        public bool? IsRead { get; set; }

        // Navigation property to relate Novel to Chapters
        public ICollection<ChapterModel> Chapters { get; set; }

        public NovelModel()
        {
                
        }

        public NovelModel(string name, string url, string chapter, string status)
        {
            Name = name;
            Url = url;
            Status = status;
            Chapter = chapter;
        }
    }
}
