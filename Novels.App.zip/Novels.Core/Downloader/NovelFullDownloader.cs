﻿using HtmlAgilityPack;
using Novels.Core.Data;
using System;
using System.Collections.Generic;
using System.Net;
using System.Text.RegularExpressions;
using System.Web;
using System.Xml.Linq;

namespace Novels.Core.Downloader
{
    public class NovelFullDownloader : IDownloader
    {
        private String _baseUrl = "https://novelfull.com";
        private String _baseUrlAll = "https://www.wuxiaspot.com/list/all/all-onclick-{0}.html";
        private String _baseUrlTag = "https://www.wuxiaspot.com/e/tags/index.php?page={0}&tagid={1}&line=100&tempid=9";
        private String _baseUrlCategorie = "https://novelfull.net/genre/{0}?page={1}";
        private HtmlWeb _htmlWeb;

        public NovelFullDownloader()
        {
            _htmlWeb = new HtmlWeb();
            _htmlWeb.PostResponse = (request, response) =>
            {
                if (response != null)
                {
                    var lastStatusCode = response.StatusCode;
                    if (lastStatusCode == (HttpStatusCode)429 && response.Headers["Retry-After"] != null)
                    {
                        int retryAfterSeconds;
                        if (int.TryParse(response.Headers["Retry-After"], out retryAfterSeconds))
                        {
                            Thread.Sleep(TimeSpan.FromSeconds(retryAfterSeconds));
                        }
                    }
                }
            };
        }

        public List<NovelModel> GetAll()
        {
            var boxNovelData = new List<NovelModel>();
            try
            {
                List<string> listCategories = new List<string>()
                {
                    "Harem",
                    //"Shounen",
                    //"Comedy",
                    //"Martial Arts",
                    //"School Life",
                    //"Mystery",
                    //"Shoujo",
                    //"Romance",
                    //"Sci-fi",
                    //"Gender Bender",
                    //"Mature",
                    //"Fantasy",
                    //"Horror",
                    //"Drama",
                    //"Tragedy",
                    //"Supernatural",
                    //"Ecchi",
                    //"Xuanhuan",
                    //"Adventure",
                    //"Action",
                    //"Psychological",
                    //"Xianxia",
                    //"Wuxia",
                    //"Historical",
                    //"Slice of Life",
                    //"Seinen",
                    //"Lolicon",
                    //"Adult",
                    //"Josei",
                    //"Sports",
                    //"Smut",
                    //"Mecha",
                    //"Yaoi",
                    //"Shounen Ai",
                    //"Magical Realism",
                    //"Video Games",
                    //"MartialGame",
                    //"Yuri",
                    //"Magical",
                    //"Reincarnation",
                    //"LGBT+",
                    //"Manhua",
                    //"TragedIsekai",
                    //"Magic",
                    //"Shoujo Ai",
                    //"LitRPG",
                    //"Eastern",
                    //"System",
                    //"Hentai",       
                };

                foreach (var category in listCategories)
                {
                    

                    HtmlAgilityPack.HtmlDocument doc = _htmlWeb.Load(string.Format(_baseUrlCategorie, category, 1));
                    HtmlNode[] nodes = doc.DocumentNode
                        .SelectNodes("//div[contains(@class, 'list-truyen')]/div[contains(@class, 'row')]") //
                        .ToArray();
                    var pagination = doc.DocumentNode
                        .SelectSingleNode($"//ul[contains(@class, 'pagination')]/li[last()]/a");
                    int pages = 0;
                    if (pagination != null)
                    {
                        string hrefValue = pagination.Attributes["href"].Value;

                        var match = Regex.Match(hrefValue, @"page=(\d+)");
                        if (match.Success)
                        {
                            string pageNumber = match.Groups[1].Value;
                            int.TryParse(pageNumber, out pages);
                        }
                    }

                    foreach (HtmlNode item in nodes)
                    {
                        var title = HttpUtility.HtmlDecode(
                            item?.SelectSingleNode(".//div/h3[@class='truyen-title']/a")
                            ?.InnerText
                            );

                        var latestchapter = /*StringFormat.TrimAllWithInplaceCharArray(*/
                            HttpUtility.HtmlDecode(
                                item?.SelectSingleNode(".//div/div/a/span[@class='chapter-text']")
                                ?.InnerText
                                )?.Trim()/*)*/;

                        var link = HttpUtility.HtmlDecode(
                            item?.SelectSingleNode(".//div/h3[@class='truyen-title']/a[@href]")
                            ?.GetAttributeValue("href", string.Empty)
                            );

                        if (!string.IsNullOrEmpty(link))
                            link = _baseUrl + link;

                        var imagelink = HttpUtility.HtmlDecode(
                            item?.SelectSingleNode(".//img")
                            ?.Attributes["src"]
                            ?.Value
                            );

                        if (!string.IsNullOrEmpty(imagelink))
                            imagelink = _baseUrl + imagelink;

                        var rating = "0";

                        boxNovelData.Add(new NovelModel()
                        {
                            Name = title,
                            Url = link,
                            //Status = status,
                            Chapter = latestchapter,
                        });
                    }

                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

            return boxNovelData;
        }

        public NovelModel GetNovel(NovelModel novel)
        {
            string author = string.Empty, artist = string.Empty,
                genre = string.Empty, release = string.Empty,
                imglink = string.Empty, status = string.Empty;
            try
            {
                HtmlAgilityPack.HtmlDocument doc = _htmlWeb.Load($"{_baseUrl}");

                doc.OptionEmptyCollection = true;

                HtmlNode imgnode = doc.DocumentNode.SelectNodes("//div[@class='book']").FirstOrDefault();

                imglink = imgnode.SelectSingleNode("img").Attributes["src"].Value;
                if (!string.IsNullOrEmpty(imglink))
                    imglink = "https://novelfull.com" + imglink;

                HtmlNode nodes = doc.DocumentNode.SelectNodes("//div[@class='info']/div").Where(x => x.InnerText.Contains("Author:")).FirstOrDefault();
                author = HttpUtility.HtmlDecode(
                               nodes?.InnerText
                           ?.Replace("Author:", ""));

                HtmlNode nodes1 = doc.DocumentNode.SelectNodes("//div[@class='info']/div").Where(x => x.InnerText.Contains("Genre:")).FirstOrDefault();
                genre = HttpUtility.HtmlDecode(
                               nodes1?.InnerText
                           ?.Replace("Genre:", ""));

                artist = "Unknown";

                release = "Unknown";

                HtmlNode nodes2 = doc.DocumentNode.SelectNodes("//div[@class='info']/div").Where(x => x.InnerText.Contains("Status:")).FirstOrDefault();
                status = HttpUtility.HtmlDecode(
                               nodes2?.InnerText
                           ?.Replace("Status:", ""));
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }


            return novel;
        }

        public List<ChapterModel> GetChapters(NovelModel novel)
        {
            throw new NotImplementedException();
        }
    }
}
