﻿using HtmlAgilityPack;
using Microsoft.EntityFrameworkCore;
using Novels.Core.Data;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Net;
using System.Text.RegularExpressions;

namespace Novels.Core.Downloader
{
    public class WuxiaDownloader : IDownloader
    {
        private String _baseUrl = "https://www.wuxiaspot.com";
        private String _baseUrlAll = "https://www.wuxiaspot.com/list/all/all-onclick-{0}.html";
        private String _baseUrlTag = "https://www.wuxiaspot.com/e/tags/index.php?page={0}&tagid={1}&line=100&tempid=9";
        private String _baseUrlCategorie = "https://www.wuxiaspot.com/list/{0}/all-newstime-{1}.html";

        private HtmlWeb _htmlWeb;

        public WuxiaDownloader()
        {
            _htmlWeb = new HtmlWeb();
            _htmlWeb.PostResponse = (request, response) =>
            {
                if (response != null)
                {
                    var lastStatusCode = response.StatusCode;
                    if (lastStatusCode == (HttpStatusCode)429 && response.Headers["Retry-After"] != null)
                    {
                        int retryAfterSeconds;
                        if (int.TryParse(response.Headers["Retry-After"], out retryAfterSeconds))
                        {
                            Thread.Sleep(TimeSpan.FromSeconds(retryAfterSeconds));
                        }
                    }
                }
            };
        }

        public List<NovelModel> GetAll()
        {
            ConcurrentBag<NovelModel> allNovels = new ConcurrentBag<NovelModel>();

            Parallel.For(0, 1232, i =>
            {
                // Load Chinese Series for each page
                var series = GetAllByUrl(string.Format(_baseUrlAll, i));

                // Add the results to the collection
                foreach (var s in series)
                {
                    var serie = allNovels.FirstOrDefault(x => x.Name.ToLowerInvariant() == s.Name.ToLowerInvariant());
                    if (serie != null)
                    {
                    }
                    else
                    {
                        allSeries.Add(s);
                    }
                }
            });

            return allNovels.ToList();
        }

        public List<NovelModel> GetAllByCategories()
        {
            ConcurrentBag<NovelModel> allNovels = new ConcurrentBag<NovelModel>();
            Dictionary<string, string> categories = new Dictionary<string, string>()
            {
                //{ "martial-arts", "martial-arts"},
                //{ "harem", "Harem"},
                //{ "wuxia", "wuxia"},
                //{ "Xuanhuan", "Xuanhuan"},
                //{ "fantasy", "Fantasy"},
                //{ "yaoi", "Yaoi"},
                //{ "yuri", "Yuri"},
                //{ "shoujo", "Shoujo"},
                //{ "shoujo-ai", "Shoujo-ai"},
                //{ "fan-fiction", "Fan-fiction"},
                //{ "shounen-ai", "Shounen-ai"},
                //{ "urban-life", "Urban-life"},
                //{ "gender-bender", "Gender-bender"},
                //{ "urban", "Urban"},
                //{ "romance", "Romance"},
                //{ "josei", "Josei"},
                //{ "sci-fi", "Sci-fi"},
                //{ "action", "Action"},
                //{ "adventure", "Adventure"},
                //{ "game", "Game"},
            };
            foreach (var item in categories)
            {
                GetAllByCategory(allNovels, item.Key, item.Value);
            }
            Dictionary<int, string> tags = new Dictionary<int, string>()
            {
                //{ 677, "Harem"},
                //{ 3, "MaleProtagonist"},
                //{ 5, "System"},
                //{ 6, "Transmigration"},
                //{ 8, "Cultivation"},
                //{ 122, "Reincarnation"},
                //{ 72, "KingdomBuilding"},
                //{ 28, "Cheats"},
                //{ 1013, "R18"},
                //{ 81, "FemaleProtagonist"},
                //{ 116, "DevotedLoveInterests"},
                //{ 150, "Apocalypse"},
                //{ 80, "Farming"},
                //{ 34, "GameElements"},
                //{ 685, "Action"},
                //{ 47 , "BeautifulFemaleLead" }
            };
            foreach (var item in tags)
            {
                GetAllByTag(allNovels, item.Key, item.Value);
            }

            return allNovels.ToList();
        }

        public NovelModel GetNovel(NovelModel novel)
        {
            throw new NotImplementedException();
        }

        public List<ChapterModel> GetChapters(NovelModel novel)
        {
            throw new NotImplementedException();
        }

        #region Private


        private List<NovelModel> GetAllByUrl(string url)
        {
            var catalogDocument = _htmlWeb.Load(url);
            List<NovelModel> seriesToLoad = new List<NovelModel>();
            HtmlNodeCollection seriesAnchors = catalogDocument.DocumentNode.SelectNodes($"//li[@class='novel-item']/a");

            foreach (HtmlNode item in seriesAnchors)
            {
                var innerHtmlDoc = new HtmlDocument();
                innerHtmlDoc.LoadHtml(item.InnerHtml);


                HtmlNodeCollection novelStats = innerHtmlDoc.DocumentNode.SelectNodes($"//div[@class='novel-stats']");
                //h4[@class='novel-title']
                string novelName = innerHtmlDoc.DocumentNode
                    .SelectNodes($"//*")
                    .Where(n => n.HasClass("novel-title"))
                    .FirstOrDefault()
                    .InnerText;
                string novelUrl = item.GetAttributeValue("href", "");
                string novelChapters = novelStats
                    .FirstOrDefault(c => c.InnerHtml.ToLowerInvariant().Contains("chapter"))
                    .InnerText
                    .ToLowerInvariant()
                    .Replace("book", "")
                    .Replace("chapters", "")
                    .Trim();
                string novelStatus = novelStats
                    .FirstOrDefault(c => c.InnerHtml.ToLowerInvariant().Contains("status"))
                    .InnerText
                    .ToLowerInvariant()
                    .Replace("status", "")
                    .Replace(":", "")
                    .Trim();

                seriesToLoad.Add(new NovelModel(novelName, novelUrl, novelChapters, novelStatus));
            }

            return seriesToLoad;
        }

        private void GetAllByTag(ConcurrentBag<NovelModel> allNovels, int tagId, string tagName)
        {
            int pages = 0;
            var catalogDocument = _htmlWeb.Load(string.Format(_baseUrlTag, 0, tagId));
            var pagination = catalogDocument.DocumentNode
                .SelectSingleNode($"//div[@class='pagination-container']");

            var innerHtmlDoc = new HtmlDocument();
            innerHtmlDoc.LoadHtml(pagination.InnerHtml);

            var lastAnchorNode = innerHtmlDoc.DocumentNode
                .SelectSingleNode("(//a[@href])[last()]");

            if (lastAnchorNode != null)
            {
                string hrefValue = lastAnchorNode.Attributes["href"].Value;

                // Extract the number after "page=" using regex
                var match = Regex.Match(hrefValue, @"page=(\d+)");
                if (match.Success)
                {
                    string pageNumber = match.Groups[1].Value;
                    int.TryParse(pageNumber, out pages);
                }
            }
            Parallel.For(0, pages, i =>
            {
                // Load Chinese Series for each page
                var series = GetAllByUrl(string.Format(_baseUrlTag, i, tagId));

                // Add the results to the collection
                foreach (var s in series)
                {
                    var serie = allNovels.FirstOrDefault(x => x.Name.ToLowerInvariant() == s.Name.ToLowerInvariant());
                    if (serie != null)
                    {
                        serie.Tags = AddOrUpdate(serie.Tags, tagName);
                    }
                    else
                    {
                        s.Tags = tagName;
                        allNovels.Add(s);
                    }
                }
            });
        }

        private void GetAllByCategory(ConcurrentBag<NovelModel> allNovels, string categorieId, string categorieName)
        {
            int pages = 0;

            var catalogDocument = _htmlWeb.Load(string.Format(_baseUrlCategorie, categorieId, 0));
            var lastAnchorNode = catalogDocument.DocumentNode.SelectSingleNode("(//ul[@class='pagination']//a)[last()]");

            if (lastAnchorNode != null)
            {
                string hrefValue = lastAnchorNode.Attributes["href"].Value;

                // Extract the number after the last hyphen using regex
                var match = Regex.Match(hrefValue, @"-(\d+)\.html$");
                if (match.Success)
                {
                    string pageNumber = match.Groups[1].Value;
                    int.TryParse(pageNumber, out pages);
                }
            }

            Parallel.For(0, pages, i =>
            {
                // Load Chinese Series for each page
                var series = GetAllByUrl(string.Format(_baseUrlCategorie, categorieId, i));

                // Add the results to the collection
                foreach (var s in series)
                {
                    var serie = allNovels.FirstOrDefault(x => x.Name.ToLowerInvariant() == s.Name.ToLowerInvariant());
                    if (serie != null)
                    {
                        serie.Tags = AddOrUpdate(serie.Tags, categorieName);
                    }
                    else
                    {
                        s.Tags = categorieName;
                        allNovels.Add(s);
                    }
                }
            });
        }
        private string AddOrUpdate(string tags, string tag)
        {
            if (!string.IsNullOrEmpty(tags) && tags.Contains(tag))
            {

            }
            else
            {
                tags = !string.IsNullOrEmpty(tags) ? string.Join(",", tags, tag) : tag;
            }

            return tags;
        }

        #endregion Private
    }
}
