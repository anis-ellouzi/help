﻿using Novels.Core.Data;
using System;
using System.Collections.Generic;

namespace Novels.Core.Downloader
{
    public interface IDownloader
    {
        
        public List<NovelModel> GetAll();
        public List<NovelModel> GetAllByCategories();

        public NovelModel GetNovel(NovelModel novel);

        public List<ChapterModel> GetChapters(NovelModel novel);

    }
}
