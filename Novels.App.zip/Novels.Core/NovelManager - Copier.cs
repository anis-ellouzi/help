﻿using System;
using System.Collections;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

using HtmlAgilityPack;
using QuickEPUB;
using Novels.Core.Data;
using System.Runtime.CompilerServices;

namespace Novels.Core
{
    public class NovelManager
    {
        private String _baseUrl = "https://www.wuxiaspot.com";
        private String _baseUrlAll = "https://www.wuxiaspot.com/list/all/all-onclick-{0}.html";
        private String _baseUrlTag = "https://www.wuxiaspot.com/e/tags/index.php?page={0}&tagid={1}&line=100&tempid=9";
        private String _baseUrlCategorie = "https://www.wuxiaspot.com/list/{0}/all-newstime-{1}.html";
        private HtmlDocument catalogDocument;
        private NovelContext _context;
        private HtmlWeb _htmlWeb;
        public NovelManager(NovelContext context)
        {
            _context = context ?? new NovelContext();
            _htmlWeb = new HtmlWeb();
            _htmlWeb.PostResponse = (request, response) =>
            {
                if (response != null)
                {
                    var lastStatusCode = response.StatusCode;
                    if (lastStatusCode == (HttpStatusCode)429 && response.Headers["Retry-After"] != null)
                    {
                        int retryAfterSeconds;
                        if (int.TryParse(response.Headers["Retry-After"], out retryAfterSeconds))
                        {
                            Thread.Sleep(TimeSpan.FromSeconds(retryAfterSeconds));
                        }
                    }
                }
            };
        }

        #region GetAll

        public void GetAll()
        {
            List<NovelModel> seriesToLoad = _context.Novels.ToList();
            //List<Novel> allSeries = new List<Novel>();
            ConcurrentBag<NovelModel> allSeries = new ConcurrentBag<NovelModel>();

            Parallel.For(0, 1232, i =>
            {
                // Load Chinese Series for each page
                var series = GetAllByUrl(string.Format(_baseUrlAll, i));

                // Add the results to the collection
                foreach (var s in series)
                {
                    var serie = seriesToLoad.FirstOrDefault(x => x.Name.ToLowerInvariant() == s.Name.ToLowerInvariant());
                    if (serie != null)
                    {
                    }
                    else
                    {
                        allSeries.Add(s);
                    }
                }
            });

            _context.Novels.UpdateRange(seriesToLoad);
            _context.Novels.AddRange(allSeries.ToList());
            _context.SaveChanges();
        }

        public void GetAllByTags()
        {
            Dictionary<int, string> tags = new Dictionary<int, string>()
            {
                //{ 677, "Harem"},
                //{ 3, "MaleProtagonist"},
                //{ 5, "System"},
                //{ 6, "Transmigration"},
                //{ 8, "Cultivation"},
                //{ 122, "Reincarnation"},
                //{ 72, "KingdomBuilding"},
                //{ 28, "Cheats"},
                //{ 1013, "R18"},
                //{ 81, "FemaleProtagonist"},
                //{ 116, "DevotedLoveInterests"},
                //{ 150, "Apocalypse"},
                //{ 80, "Farming"},
                //{ 34, "GameElements"},
                //{ 685, "Action"},
                //{ 47 , "BeautifulFemaleLead" }
            };
            foreach (var item in tags)
            {
                GetAllByTag(_context.Novels.ToList(), item.Key, item.Value);
            }
        }

        public void GetAllByTag(List<NovelModel> seriesToLoad, int tagId, string tagName)
        {
            int pages = 0;
            //List<Novel> allSeries = new List<Novel>();seriesToLoad
            ConcurrentBag<NovelModel> allSeries = new ConcurrentBag<NovelModel>();

            catalogDocument = _htmlWeb.Load(string.Format(_baseUrlTag, 0, tagId));
            var pagination = catalogDocument.DocumentNode
                .SelectSingleNode($"//div[@class='pagination-container']");


            var innerHtmlDoc = new HtmlDocument();
            innerHtmlDoc.LoadHtml(pagination.InnerHtml);

            var lastAnchorNode = innerHtmlDoc.DocumentNode
                .SelectSingleNode("(//a[@href])[last()]");

            if (lastAnchorNode != null)
            {
                string hrefValue = lastAnchorNode.Attributes["href"].Value;

                // Extract the number after "page=" using regex
                var match = Regex.Match(hrefValue, @"page=(\d+)");
                if (match.Success)
                {
                    string pageNumber = match.Groups[1].Value;
                    int.TryParse(pageNumber, out pages);
                }
            }
            Parallel.For(0, pages, i =>
            {
                // Load Chinese Series for each page
                var series = GetAllByUrl(string.Format(_baseUrlTag, i, tagId));

                // Add the results to the collection
                foreach (var s in series)
                {
                    var serie = seriesToLoad.FirstOrDefault(x => x.Name.ToLowerInvariant() == s.Name.ToLowerInvariant());
                    if (serie != null)
                    {
                        serie.Tags = AddOrUpdate(serie.Tags, tagName);
                    }
                    else
                    {
                        s.Tags = tagName;
                        allSeries.Add(s);
                    }
                }
            });
            _context.Novels.UpdateRange(seriesToLoad);
            _context.Novels.AddRange(allSeries.ToList());
            _context.SaveChanges();
        }

        public void GetAllCategories()
        {
            List<NovelModel> seriesToLoad = _context.Novels.ToList();
            Dictionary<string, string> categories = new Dictionary<string, string>()
            {
                //{ "martial-arts", "martial-arts"},
                //{ "harem", "Harem"},
                //{ "wuxia", "wuxia"},
                //{ "Xuanhuan", "Xuanhuan"},
                //{ "fantasy", "Fantasy"},
                //{ "yaoi", "Yaoi"},
                //{ "yuri", "Yuri"},
                //{ "shoujo", "Shoujo"},
                //{ "shoujo-ai", "Shoujo-ai"},
                //{ "fan-fiction", "Fan-fiction"},
                //{ "shounen-ai", "Shounen-ai"},
                //{ "urban-life", "Urban-life"},
                //{ "gender-bender", "Gender-bender"},
                //{ "urban", "Urban"},
                //{ "romance", "Romance"},
                //{ "josei", "Josei"},
                //{ "sci-fi", "Sci-fi"},
                //{ "action", "Action"},
                //{ "adventure", "Adventure"},
                //{ "game", "Game"},
            };
            foreach (var item in categories)
            {
                GetAllCategory(seriesToLoad, item.Key, item.Value);
            }
        }

        public void GetAllCategory(List<NovelModel> seriesToLoad, string categorieId, string categorieName)
        {
            int pages = 0;
            //List<Novel> allSeries = new List<Novel>();seriesToLoad
            ConcurrentBag<NovelModel> allSeries = new ConcurrentBag<NovelModel>();

            catalogDocument = _htmlWeb.Load(string.Format(_baseUrlCategorie, categorieId, 0));
            var lastAnchorNode = catalogDocument.DocumentNode.SelectSingleNode("(//ul[@class='pagination']//a)[last()]");

            if (lastAnchorNode != null)
            {
                string hrefValue = lastAnchorNode.Attributes["href"].Value;

                // Extract the number after the last hyphen using regex
                var match = Regex.Match(hrefValue, @"-(\d+)\.html$");
                if (match.Success)
                {
                    string pageNumber = match.Groups[1].Value;
                    int.TryParse(pageNumber, out pages);
                }
            }

            Parallel.For(0, pages, i =>
            {
                // Load Chinese Series for each page
                var series = GetAllByUrl(string.Format(_baseUrlCategorie, categorieId, i));

                // Add the results to the collection
                foreach (var s in series)
                {
                    var serie = seriesToLoad.FirstOrDefault(x => x.Name.ToLowerInvariant() == s.Name.ToLowerInvariant());
                    if (serie != null)
                    {
                        serie.Tags = AddOrUpdate(serie.Tags, categorieName);
                    }
                    else
                    {
                        s.Tags = categorieName;
                        allSeries.Add(s);
                    }
                }
            });
            _context.Novels.UpdateRange(seriesToLoad);
            _context.Novels.AddRange(allSeries.ToList());
            _context.SaveChanges();
        }

        private List<NovelModel> GetAllByUrl(string baseUrl)
        {
            catalogDocument = _htmlWeb.Load(baseUrl);
            List<NovelModel> seriesToLoad = new List<NovelModel>();
            HtmlNodeCollection seriesAnchors = catalogDocument.DocumentNode.SelectNodes($"//li[@class='novel-item']/a");

            foreach (HtmlNode item in seriesAnchors)
            {
                var innerHtmlDoc = new HtmlDocument();
                innerHtmlDoc.LoadHtml(item.InnerHtml);


                HtmlNodeCollection novelStats = innerHtmlDoc.DocumentNode.SelectNodes($"//div[@class='novel-stats']");
                //h4[@class='novel-title']
                string novelName = innerHtmlDoc.DocumentNode
                    .SelectNodes($"//*")
                    .Where(n => n.HasClass("novel-title"))
                    .FirstOrDefault()
                    .InnerText;
                string novelUrl = item.GetAttributeValue("href", "");
                string novelChapters = novelStats
                    .FirstOrDefault(c => c.InnerHtml.ToLowerInvariant().Contains("chapter"))
                    .InnerText
                    .ToLowerInvariant()
                    .Replace("book", "")
                    .Replace("chapters", "")
                    .Trim();
                string novelStatus = novelStats
                    .FirstOrDefault(c => c.InnerHtml.ToLowerInvariant().Contains("status"))
                    .InnerText
                    .ToLowerInvariant()
                    .Replace("status", "")
                    .Replace(":", "")
                    .Trim();

                seriesToLoad.Add(new NovelModel(novelName, novelUrl, novelChapters, novelStatus));
            }

            return seriesToLoad;
        }

        #endregion GetAll

        #region UpdateAll

        public async Task UpdateAll()
        {
            List<NovelModel> seriesToLoad = _context.Novels.ToList()
                    .Where(novel =>
                        !string.IsNullOrWhiteSpace(novel.Tags) &&
                        !string.IsNullOrWhiteSpace(novel.Chapter) &&
                        //!novel.Chapter.Contains(".") &&
                        //!novel.Chapter.Contains("」") &&
                        //!novel.Chapter.Contains("]") &&
                        !novel.Tags.Contains("yuri") &&
                        !novel.Tags.Contains("Yaoi") &&
                        !novel.Tags.Contains("Shoujo") &&
                        !novel.Tags.Contains("FemaleProtagonist") &&
                        //!novel.Tags.Contains("urban") &&
                        //!novel.Tags.Contains("Fan-fiction") &&
                        !novel.Tags.Contains("Gender-bender") &&
                        !novel.Tags.Contains("BeautifulFemaleLead") &&
                        !novel.Tags.Contains("FemaleProtagonist") &&
                        !novel.Tags.Contains("Josei") &&
                        //!novel.Tags.Contains("Romance") &&
                        decimal.Parse(novel.Chapter) > 299) // && !novel.UpdatedOn.HasValue
                    .ToList(); ;
            ConcurrentBag<NovelModel> allSeries = new ConcurrentBag<NovelModel>();
            // Group seriesToLoad into batches of 5
            var batches = seriesToLoad.Select((novel, index) => new { novel, index })
                                      .GroupBy(x => x.index / 18)
                                      .Select(g => g.Select(x => x.novel).ToList())
                                      .ToList();
            int i = 0;

            // Process each batch in parallel
            foreach (var batch in batches)
            {
                var tasks = batch.Select(c => Update(c));
                await Task.WhenAll(tasks);
                //Thread.Sleep(10000);
                i++;
            }
            _context.Novels.UpdateRange(seriesToLoad);
            //_context.Novels.AddRange(allSeries.ToList());
            _context.SaveChanges();
        }

        public async Task Update(NovelModel novel)
        {
            try
            {
                ConcurrentBag<ChapterModel> allSeries = new ConcurrentBag<ChapterModel>();

                String novelName = novel.Name;
                String novelUrl = _baseUrl + novel.Url;
                var novelPage = _htmlWeb.Load(string.Format(novelUrl));
                var summaryNode = novelPage.DocumentNode.SelectSingleNode("//div[@class='summary']");
                var cat = novelPage.DocumentNode
                    .SelectSingleNode("//div[@class='categories']");
                //var tagsNode = novelPage.DocumentNode.SelectSingleNode("//div[@class='categories']");
                var coverNode = novelPage.DocumentNode.SelectSingleNode("//header[@class='novel-header']");
                //var imgNode = coverNode.SelectSingleNode(".//img");
                //string coverImageUrl = _baseUrl + imgNode.Attributes["src"].Value;
                novel.Summary = summaryNode.InnerHtml;

                var innerHtmlDoc = new HtmlDocument();
                innerHtmlDoc.LoadHtml(cat.InnerHtml);

                HtmlNodeCollection tagsNode = innerHtmlDoc.DocumentNode
                    .SelectNodes($"//li/a");
                foreach (HtmlNode item in tagsNode)
                {
                    //var innerHtmlDoc = new HtmlDocument();
                    //innerHtmlDoc.LoadHtml(item.InnerText);
                    novel.Tags = AddOrUpdate(novel.Tags, item.InnerText);
                }
                novel.UpdatedOn = DateTime.Now;
                Console.WriteLine($"Updated {novel.Name}");
            }
            catch (Exception)
            {
                Console.WriteLine($"Updated failed {novel.Name}");
            }

        }


        #endregion UpdateAll

        #region Export

        public async Task Export(NovelModel novel)
        {
            ConcurrentBag<ChapterModel> allSeries = new ConcurrentBag<ChapterModel>();
            // Create an Epub instance
            var doc = new Epub("Book Title", "Author Name");
            String storyName = novel.Name;
            String tocHeader = "<!DOCTYPE html><html><head><meta charset=\"utf-8\"></head><body><h1>" + storyName + "</h1><ul>";

            int chapters = int.Parse(novel.Chapter);
            String novelUrl = _baseUrl + novel.Url;
            String chapterUrl = novelUrl.Replace(".html", "_{0}.html");

            var novelPage = _htmlWeb.Load(string.Format(novelUrl));

            var summaryNode = novelPage.DocumentNode.SelectSingleNode("//div[@class='summary']");
            var coverNode = novelPage.DocumentNode.SelectSingleNode("//figure[@class='cover']");
            var imgNode = coverNode.SelectSingleNode(".//img");

            string coverImageUrl = _baseUrl + imgNode.Attributes["data-src"].Value;

            var imageData = GetImageStreamFromUrlAsync(coverImageUrl);
                // Convert the byte array to a MemoryStream
            MemoryStream coverStream = new MemoryStream(imageData);
            // Add the cover image to the EPUB resources
            doc.AddResource("cover.jpg", EpubResourceType.JPEG, coverStream);

            // Adding the cover page (with the fetched image)
            doc.AddSection("Cover", "<img src=\"cover.jpg\" alt=\"Cover\"/>");

            // Adding the summary section
            doc.AddSection("Summary", summaryNode.InnerHtml);

            // Create the list of numbers from start to end
            List<int> numbers = CreateNumberList(1, chapters);
            for (int chapNum = 1; chapNum < 5; chapNum++)
            {
                var chapterPage = _htmlWeb.Load(string.Format(chapterUrl, chapNum));
                int maxRetry = 3;
                bool isSucces = false;
                do
                {
                    isSucces = false;
                    try
                    {
                        Console.WriteLine("Fetching: " + storyName + "Chapter" + chapNum);
                        string next = "<a href=Chapter-\" + (chapNum - 1).ToString().PadLeft(5, '0') + \".html>Prev</a><a href=Chapter-" + (chapNum + 1).ToString().PadLeft(5, '0') + ".html>Next</a>";

                        var chapterNode = chapterPage.DocumentNode.SelectSingleNode("//div[@class='chapter-content']");
                        var titlesNode = chapterPage.DocumentNode.SelectSingleNode("//*[@class='titles']");
                        var trueChapNum = chapNum.ToString().PadLeft(5, '0');

                        var linkNodes = titlesNode?.SelectNodes(".//a");

                        // Remove each <a> tag found
                        if (linkNodes != null)
                        {
                            foreach (var linkNode in linkNodes)
                            {
                                linkNode.Remove();
                            }
                        }

                        // Get the modified HTML content
                        string title = titlesNode.InnerHtml;

                        string chapterContent = "<!DOCTYPE html><html><head><meta charset=\"utf-8\"></head>\n<body>" + titlesNode?.InnerHtml + "<Br/>" + chapterNode?.InnerHtml + " </body></html>";
                        allSeries.Add(new ChapterModel()
                        {
                            Number = chapNum,
                            Name = titlesNode.InnerText ?? "Chapter " + chapNum,
                            Content = chapterContent,
                            Url = string.Format(chapterUrl, chapNum)
                        });
                        isSucces = true;
                    }
                    catch (Exception e)
                    {
                        Console.WriteLine("Error in chapter " + chapNum);
                        //Console.WriteLine(e);

                    }
                    maxRetry++;
                } 
                while (maxRetry < 3 && !isSucces);
                
            }
            // Group numbers by packSize
            List<List<int>> groupedNumbers = GroupByPack(numbers, 5);
            foreach (var number in groupedNumbers)
            {
                int min = number.Min();
                int max = number.Max();
                Parallel.For(min, max, chapNum =>
                {
                    //ChapterLoader chapterLoader = new ChapterLoader(string.Format(chapterUrl, i));
                    //string body = chapterLoader.GetChapterBody();


                });

            }

            //// Add the CSS file referenced in the HTML content
            //using (var cssStream = new FileStream("custom.css", FileMode.Open))
            //{
            //    doc.AddResource("custom.css", EpubResourceType.CSS, cssStream);
            //}
            foreach (var item in allSeries.OrderBy(c => c.Number))
            {
                doc.AddSection(item.Name, item.Content);
            }
            // Export the result
            using (var fs = new FileStream(novel.Name + ".epub", FileMode.Create))
            {
                doc.Export(fs);
            }
        }

        #endregion

        public string AddOrUpdate(string tags, string tag)
        {
            if (!string.IsNullOrEmpty(tags) && tags.Contains(tag))
            {

            }
            else
            {
                tags = !string.IsNullOrEmpty(tags) ? string.Join(",", tags, tag) : tag;
            }

            return tags;
        }

        static byte[]? GetImageStreamFromUrlAsync(string imageUrl)
        {
            try
            {
                // Create an instance of WebClient
                using WebClient webClient = new WebClient();

                // Download the image data as a byte array
                byte[] imageData = webClient.DownloadData(imageUrl);

                return imageData;
            }
            catch (Exception)
            {

                throw;
            }
        }
        static List<int> CreateNumberList(int start, int end)
        {
            List<int> numbers = new List<int>();
            for (int i = start; i <= end; i++)
            {
                numbers.Add(i);
            }
            return numbers;
        }

        static List<List<int>> GroupByPack(List<int> numbers, int packSize)
        {
            List<List<int>> groupedNumbers = new List<List<int>>();

            for (int i = 0; i < numbers.Count; i += packSize)
            {
                List<int> group = numbers.GetRange(i, Math.Min(packSize, numbers.Count - i));
                groupedNumbers.Add(group);
            }

            return groupedNumbers;
        }

        static async Task<string> GetResponseTextAsync(string url)
        {
            using (HttpClient client = new HttpClient())
            {
                // Send the request and get the response
                using (HttpResponseMessage response = await client.GetAsync(url))
                {
                    response.EnsureSuccessStatusCode(); // Throws an exception if the HTTP response status is an error code

                    // Get the response content as a string
                    string responseText = await response.Content.ReadAsStringAsync();
                    return responseText;
                }
            }
        }


    }
}
