﻿using HtmlAgilityPack;
using QuickEPUB;
using WuxiaWorldDLER.Data;
namespace WuxiaWorldDLER
{
    public class SeriesLoader
    {
        private Novel series;

        public SeriesLoader(Novel series)
        {
            this.series = series;
        }

        public void SaveSeries()
        {
            List<String> allChapters = GetAllChapters();
            for (int i = 0; i < allChapters.Count; i++)
            {
                String chapterUrl = allChapters[i];
                ChapterLoader chapterLoader = new ChapterLoader(chapterUrl);
                string body = chapterLoader.GetChapterBody();

                Console.WriteLine(chapterUrl);

                SaveChapter(i + 1, body);
            }
        }

        private void SaveChapter(int chapterNumber, String body)
        {
            ChapterXHTMLCreator htmlCreator = new ChapterXHTMLCreator(series.Name, chapterNumber, body);
            string path = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), $"xhtml/{series.Name}/chap{chapterNumber}.xhtml");
            Directory.CreateDirectory(Path.GetDirectoryName(path));
            htmlCreator.SaveChapter(path);
        }

        private List<String> GetAllChapters()
        {
            HtmlWeb web = new HtmlWeb();
            HtmlDocument seriesDocument = web.Load(series.Url);

            return seriesDocument.DocumentNode.SelectNodes("//div[@itemprop='articleBody']//a").Select(n => n.GetAttributeValue("href", "")).Distinct().ToList();
        }

        static String baseUrl = "https://www.wuxiaspot.com/novel/cultivating-immortals-is-a-hard-job_{0}.html";

        private void Save(Novel novel)
        {
            // Create an Epub instance
            var doc = new Epub("Book Title", "Author Name");

            // Adding sections of HTML content
            doc.AddSection("Chapter 1", "<p>Lorem ipsum dolor sit amet...</p>");

            // Adding sections of HTML content (that reference image files)
            doc.AddSection("Chapter 2", "<p><img src=\"image.jpg\" alt=\"Image\"/></p>");

            // Adding images that are referenced in any of the sections
            using (var jpgStream = new FileStream("image.jpg", FileMode.Open))
            {
                doc.AddResource("image.jpg", EpubResourceType.JPEG, jpgStream);
            }

            // Adding sections of HTML content (that use a custom CSS stylesheet)
            doc.AddSection("Chapter 3", "<p class=\"body-text\">Lorem ipsum dolor sit amet...</p>", "custom.css");

            // Add the CSS file referenced in the HTML content
            using (var cssStream = new FileStream("custom.css", FileMode.Open))
            {
                doc.AddResource("custom.css", EpubResourceType.CSS, cssStream);
            }

            // Export the result
            using (var fs = new FileStream("sample.epub", FileMode.Create))
            {
                doc.Export(fs);
            }
            /*
            var web = new HtmlWeb();
            var indexPage = web.Load(baseUrl + novelUrl);
            var chapters = indexPage.DocumentNode.SelectNodes("//li[@class='chapter-item']//a");
            String storyName = indexPage.DocumentNode.SelectSingleNode("//div[@class='section-content']//div[@class='p-15']//h4").InnerText.Trim();
            String tocHeader = "<!DOCTYPE html><html><head><meta charset=\"utf-8\"></head><body><h1>" + storyName + "</h1><ul>";
            TextWriter toc = new StreamWriter(storyName + ".html", true);

            toc.WriteLine(tocHeader);

            Console.WriteLine("Fetching: " + storyName);

            Int32 chapNum = 1;
            foreach (var chap in chapters)
            {
                //System.Threading.Thread.Sleep(1000);
                var title = chap.InnerText.Trim();

                var chapUrl = chap.Attributes["href"].Value.Trim();

                var chapterPage = web.Load(baseUrl + chapUrl);
                var chapterText = chapterPage.DocumentNode.SelectSingleNode("//div[@class='fr-view']").InnerHtml;
                Console.WriteLine("Added chapter" + chapNum.ToString() + " to database: " + title);
                chapterText = "<!DOCTYPE html><html><head><meta charset=\"utf-8\"></head>\n<body><a href=Chapter-" + (chapNum - 1).ToString().PadLeft(5, '0') + ".html>Prev</a><a href=Chapter-" + (chapNum + 1).ToString().PadLeft(5, '0') + ".html>Next</a>" + chapterText + "</body></html>";
                var trueChapNum = chapNum.ToString().PadLeft(5, '0');
                var chapFilename = "Chapter-" + trueChapNum + ".html";
                File.WriteAllText(chapFilename, chapterText);
                Console.WriteLine(chapFilename);
                toc.WriteLine("<li><a href=" + chapFilename + ">Chapter " + chapNum + "</a></li>");


                chapNum++;
            }

            toc.WriteLine("</ul></body></html>");
            toc.Close();

            Console.WriteLine("Do you want to convert to epub? (Requires Calibre) (Y/N): ");
            var shouldMakeEpub = Console.ReadKey().ToString().ToUpper() == "Y";
            if (shouldMakeEpub)
            {
                System.Diagnostics.Process.Start("ebook-convert", "\"" + storyName + ".html\" " + storyName + ".epub --max-levels 1 --max-toc-links 0");
            }
            EpubWriter writer = new EpubWriter();
            // Create a new EPUB book
            var epubBook = new EpubBook
            {
                Title = "Sample EPUB",
                Author = "Author Name",
                Language = "en",
                Identifier = "sample-epub"
            };

            // Add the HTML content as a chapter
            epubBook.AddChapter("Chapter 1", htmlContent);

            // Specify the output path for the EPUB file
            string outputPath = Path.Combine(Environment.CurrentDirectory, "SampleEpub.epub");

            // Save the EPUB file
            epubBook.Write(outputPath);*/
        }
    }
}
