﻿using Novels.Core;
using Novels.Core.Data;
using Novels.Core.Downloader;

namespace WuxiaWorldDLER
{
    class Program
    {

        static async Task Main(string[] args)
        {
            using (var context = new NovelContext())
            {
                NovelManager catalogLoader = new NovelManager(context);


                NovelFullDownloader downloader = new NovelFullDownloader();
                downloader.GetNovels();
                //await catalogLoader.UpdateAll() ;
                //await catalogLoader.Export(context.Novels.FirstOrDefault(c => c.Id == 19993));

                //Dictionary<int, string> tags = new Dictionary<int, string>()
                //{
                //    //{ 677, "Harem"},
                //    //{ 3, "MaleProtagonist"},
                //    //{ 5, "System"},
                //    //{ 6, "Transmigration"},
                //    //{ 8, "Cultivation"},
                //    //{ 122, "Reincarnation"},
                //    //{ 72, "KingdomBuilding"},
                //    //{ 28, "Cheats"},
                //    //{ 1013, "R18"},
                //    //{ 81, "FemaleProtagonist"},
                //    //{ 116, "DevotedLoveInterests"},
                //    //{ 150, "Apocalypse"},
                //    //{ 80, "Farming"},
                //    //{ 34, "GameElements"},
                //    //{ 685, "Action"},
                //    //{ 47 , "BeautifulFemaleLead" }
                //};
                //foreach (var item in tags)
                //{
                //    //catalogLoader.UpdateTags(context.Novels.ToList(), item.Key, item.Value);
                //}

            }
        }
        static void MainUpdateCatalog(string[] args)
        {

            using (var context = new NovelContext())
            {
                NovelManager catalogLoader = new NovelManager(context);
                // Ensure the database is created
                context.Database.EnsureCreated();

                // Check if the database already contains data
                if (!context.Novels.Any())
                {

                    //
                    //catalogLoader.UpdateCatalog(context.Novels.ToList(), 677);
                    //// Add novels to the database
                    //context.Novels.UpdateRange(allSeries.Where(c => c.Id > 0));
                    //context.SaveChanges();
                }
                else
                {
                }
                // Query and display the data
                //var novels = context.Novels.Include(n => n.Chapters).ToList();
                //foreach (var novel in novels)
                //{
                //    Console.WriteLine($"Novel: {novel.Name}, Status: {novel.Status}");
                //    foreach (var chapter in novel.Chapters)
                //    {
                //        Console.WriteLine($"- Chapter: {chapter.Name}");
                //    }
                //}
            }
            //Novel seriesToLoad = SelectSeries();
            //SeriesLoader seriesLoader = new SeriesLoader(seriesToLoad);
            //seriesLoader.SaveSeries();

            //const int chapterOffset = 2;

            //for (int chapter = 450; chapter <= 453; chapter++)
            //{
            //    ChapterLoader chapterLoader = new ChapterLoader(chapter);
            //    string body = chapterLoader.GetChapterBody();
            //    ChapterXHTMLCreator htmlCreator = new ChapterXHTMLCreator("Tales of Demons and Gods", chapter, body);
            //    string path = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), $"xhtml/section-0{chapter + chapterOffset}.xhtml");
            //    Directory.CreateDirectory(Path.GetDirectoryName(path));
            //    htmlCreator.SaveChapter(path);
            //}
        }

        //static Novel SelectSeries()
        //{

        //    CatalogLoader catalogLoader = new CatalogLoader(null);
        //    catalogLoader.GetCatalog();


        //    for (int i = 0; i < allSeries.Count; i++)
        //    {
        //        Console.WriteLine($"{i + 1}. {allSeries[i].Name} {allSeries[i].Url}");
        //    }

        //    Console.WriteLine("Please select a series");
        //    int selectedIndex = int.Parse(Console.ReadLine()) - 1;

        //    while (selectedIndex < 0 || selectedIndex >= allSeries.Count)
        //    {
        //        Console.WriteLine("Invalid series, please select a valid series");
        //        selectedIndex = int.Parse(Console.ReadLine()) - 1;
        //    }
        //catalogLoader.UpdateCatalog(context.Novels.ToList(), 677, "Harem");
        //catalogLoader.UpdateCatalog(context.Novels.ToList(), 3, "MaleProtagonist");
        //catalogLoader.UpdateCatalog(context.Novels.ToList(), 5, "System");
        //catalogLoader.UpdateCatalog(context.Novels.ToList(), 6, "Transmigration");
        //catalogLoader.UpdateTags(context.Novels.ToList(), 8, "Cultivation");
        //catalogLoader.UpdateTags(context.Novels.ToList(), 122, "Reincarnation");
        //catalogLoader.UpdateTags(context.Novels.ToList(), 72, "KingdomBuilding");
        //catalogLoader.UpdateTags(context.Novels.ToList(), 28, "Cheats");
        //catalogLoader.UpdateTags(context.Novels.ToList(), 1013, "R18");
        //catalogLoader.UpdateTags(context.Novels.ToList(), 81, "FemaleProtagonist");
        //catalogLoader.UpdateTags(context.Novels.ToList(), 116, "DevotedLoveInterests");
        //catalogLoader.UpdateTags(context.Novels.ToList(), 150, "Apocalypse");
        //catalogLoader.UpdateTags(context.Novels.ToList(), 80, "Farming");
        //catalogLoader.UpdateTags(context.Novels.ToList(), 34, "GameElements");
        //catalogLoader.UpdateTags(context.Novels.ToList(), 685, "Action");
        //catalogLoader.UpdateCategories(context.Novels.ToList(), "martial-arts", "martial-arts", 51);
        //catalogLoader.UpdateCategories(context.Novels.ToList(), "harem", "Harem");
        //catalogLoader.UpdateCategories(context.Novels.ToList(), "wuxia", "wuxia", 11);
        //catalogLoader.UpdateCategories(context.Novels.ToList(), "Xuanhuan", "Xuanhuan", 60);
        //catalogLoader.UpdateCategories(context.Novels.ToList(), "fantasy", "Fantasy");
        //catalogLoader.UpdateCategories(context.Novels.ToList(), "yaoi", "Yaoi");
        //catalogLoader.UpdateCategories(context.Novels.ToList(), "yuri", "Yuri");
        //catalogLoader.UpdateCategories(context.Novels.ToList(), "shoujo", "Shoujo");
        //catalogLoader.UpdateCategories(context.Novels.ToList(), "shoujo-ai", "Shoujo-ai");
        //catalogLoader.UpdateCategories(context.Novels.ToList(), "fan-fiction", "Fan-fiction");
        //catalogLoader.UpdateCategories(context.Novels.ToList(), "shounen-ai", "Shounen-ai");
        //catalogLoader.UpdateCategories(context.Novels.ToList(), "urban-life", "Urban-life");
        //catalogLoader.UpdateCategories(context.Novels.ToList(), "gender-bender", "Gender-bender");
        //catalogLoader.UpdateCategories(context.Novels.ToList(), "urban", "Urban");
        //catalogLoader.UpdateCategories(context.Novels.ToList(), "romance", "Romance");
        //catalogLoader.UpdateCategories(context.Novels.ToList(), "josei", "Josei");
        //catalogLoader.UpdateCategories(context.Novels.ToList(), "sci-fi", "Sci-fi");
        //catalogLoader.UpdateCategories(context.Novels.ToList(), "action", "Action");
        //catalogLoader.UpdateCategories(context.Novels.ToList(), "adventure", "Adventure");
        //catalogLoader.UpdateCategories(context.Novels.ToList(), "game", "Game");


        /*
        context.Novels.ToList();
        foreach (var item in allSeries)
        {
            if(!string.IsNullOrEmpty(item.Tags))
            {

                item.Tags = item.Tags.Replace("martial-arts", "");
            }

        }
        context.Novels.UpdateRange(allSeries);
        // Add novels to the database
        //context.Novels.AddRange(allSeries.Where(c => c.Id > 0));
        context.SaveChanges();*/
        //    return allSeries[selectedIndex];
        //}
    }
}
