﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace WuxiaWorldDLER.Data
{
    public class Chapter
    {

        [Key]
        public int Id { get; set; }  // Primary Key

        public string Name { get; set; }
        public string? Content { get; set; }
        public int Number { get; set; }
        public string? Url { get; set; }

        // Foreign key relationship to Novel
        [ForeignKey("Id")]
        public Novel Novel { get; set; }
    }
}