﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

namespace WuxiaWorldDLER.Data
{
    public class NovelContext : DbContext
    {
        public DbSet<Novel> Novels { get; set; }
        public DbSet<Chapter> Chapters { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            // Specify the SQLite database file
            optionsBuilder.UseSqlite("Data Source=C:\\Users\\sonde\\Downloads\\WuxiaWorldDL-master\\WuxiaWorldDL-master\\WuxiaWorldDLER\\novelsa.db");
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            // Define the primary key for Chapter
            modelBuilder.Entity<Chapter>()
                        .HasKey(c => c.Id);

            // Define the relationship between Novel and Chapters
            modelBuilder.Entity<Novel>()
                        .HasMany(n => n.Chapters)
                        .WithOne(c => c.Novel)
                        .HasForeignKey(c => c.Id);
        }
    }
}
